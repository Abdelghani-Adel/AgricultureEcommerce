"use strict";
exports.id = 202;
exports.ids = [202];
exports.modules = {

/***/ 2202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ AuthenticationAPI)
/* harmony export */ });
class AuthenticationAPI {
    async Register(reqBody) {
        const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/Auth/Register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(reqBody)
        });
        const result = await res.json();
        return result;
    }
    async Login(reqBody) {
        const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/Auth/Login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: reqBody.email,
                password: reqBody.password,
                rememberMe: reqBody.rememberMe
            })
        });
        const result = await res.json();
        console.log(result);
        return result;
    }
}


/***/ })

};
;