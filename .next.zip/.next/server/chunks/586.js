"use strict";
exports.id = 586;
exports.ids = [586];
exports.modules = {

/***/ 3182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getAuthToken),
/* harmony export */   "g": () => (/* binding */ getAuthHeaders)
/* harmony export */ });
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_0__);

async function getAuthToken() {
    if (false) {}
}
async function getAuthHeaders() {
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Origin",
        Authorization: await getAuthToken()
    };
}


/***/ }),

/***/ 5586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z8": () => (/* binding */ editCart),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "iS": () => (/* binding */ getCartDetails),
/* harmony export */   "wz": () => (/* binding */ deleteItem)
/* harmony export */ });
/* unused harmony export cartActions */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helper_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3182);



const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState: {
        items: [],
        total: 0,
        currency: "$",
        cart_id: 0
    },
    extraReducers: (builder)=>{
        builder.addCase(getCartDetails.fulfilled, (state, { payload  })=>{
            if (payload) {
                state.items = payload.items;
                state.total = payload.totalPrice;
                state.cart_id = payload.Cart_Id;
            }
        });
        builder.addCase(editCart.fulfilled, (state, { payload  })=>{
            if (payload) {
                state.items = payload.items;
                state.total = payload.totalPrice;
                state.cart_id = payload.Cart_Id;
            }
        });
        builder.addCase(deleteItem.fulfilled, (state, { payload  })=>{
            if (payload) {
                state.items = payload.items;
                state.total = payload.totalPrice;
                state.cart_id = payload.Cart_Id;
            }
            if (!payload) {
                state.items = [];
                state.total = 0;
            }
        });
    },
    reducers: {
        save: (state, param)=>{
            const { payload  } = param;
            state.location = [
                ...state.location,
                payload
            ];
        },
        clearCart: (state)=>{
            state.items = [];
            state.total = 0;
            state.cart_id = 0;
        }
    }
});
const getCartDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("cart/getCartDetails", async (payload, thunkAPI)=>{
    const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/Booking/getCartItem`, {
        method: "POST",
        headers: await (0,_helper_auth__WEBPACK_IMPORTED_MODULE_2__/* .getAuthHeaders */ .g)(),
        body: JSON.stringify({
            lang: "AR"
        })
    });
    const cartData = await res.json();
    return cartData;
});
const editCart = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("cart/editCart", async (payload, thunkAPI)=>{
    const currentState = thunkAPI.getState().cart;
    const items = currentState.items.filter((item)=>item.Item_Id == payload.item.Item_Id);
    const item = items[0] || {};
    let quoteSID = item.Quote_S_Id || 0;
    let quantity = 1;
    if (payload.action == "minus" && item.Qty == "1") {
        thunkAPI.dispatch(deleteItem(item));
    }
    if (payload.action == "plus" && item.Qty) {
        quantity = item.Qty + 1;
    }
    if (payload.action == "minus" && item.Qty) {
        quantity = item.Qty - 1;
    }
    const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/Booking/addToCart`, {
        method: "POST",
        headers: await (0,_helper_auth__WEBPACK_IMPORTED_MODULE_2__/* .getAuthHeaders */ .g)(),
        body: JSON.stringify({
            success: true,
            Message: "string",
            totalPrice: 0,
            Cart_Ref: "string",
            Cust_Id: 30,
            Cart_Id: currentState.cart_id,
            lang: "AR",
            items: [
                {
                    Quote_S_Id: quoteSID,
                    Item_Id: payload.item.Item_Id,
                    Item_Name: "test",
                    Qty: quantity,
                    UnitPrice: 5,
                    Quote_Date: "string",
                    UOM_Id: 2,
                    UOM_Name: "string",
                    Cart_Id: currentState.cart_id,
                    Supp_Id: 1,
                    lang: "AR"
                }
            ]
        })
    });
    const cartDetails = await res.json();
    return cartDetails;
});
const deleteItem = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("cart/deleteItem", async (payload, thunkAPI)=>{
    const currentState = thunkAPI.getState().cart;
    const item = currentState.items.filter((item)=>item.Item_Id == payload.Item_Id)[0];
    const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/Booking/deleteFromCart`, {
        method: "POST",
        headers: await (0,_helper_auth__WEBPACK_IMPORTED_MODULE_2__/* .getAuthHeaders */ .g)(),
        body: JSON.stringify({
            ...item,
            Cart_Id: currentState.cart_id
        })
    });
    const cartDetails = await res.json();
    return cartDetails;
});
const cartActions = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice);


/***/ })

};
;