"use strict";
(() => {
var exports = {};
exports.id = 123;
exports.ids = [123];
exports.modules = {

/***/ 8176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ Rating)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__);


function Rating(rating) {
    let stars = [];
    for(let i = 0; i < 5; i++){
        stars.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaStar, {}, i));
    }
    if (rating && rating > 0) {
        for(let i1 = 0; i1 <= rating - 1; i1++){
            stars[i1] = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaStar, {
                className: "active"
            }, i1);
        }
    }
    return stars;
}



/***/ }),

/***/ 146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _productSlug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-multi-lang"
var external_react_multi_lang_ = __webpack_require__(4243);
// EXTERNAL MODULE: ./components/layout/Reusable/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(6946);
;// CONCATENATED MODULE: ./components/Sections/products/ProductSingle/AdditionalInfo.js


const AdditionalInfo = (props)=>{
    const { item  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "row",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-lg-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "nav nav-pills d-flex flex-column",
                    id: "myTab",
                    role: "tablist",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-link active mb-2",
                            id: "v-pills-home-tab",
                            "data-bs-toggle": "pill",
                            "data-bs-target": "#v-pills-home",
                            type: "button",
                            role: "tab",
                            "aria-controls": "v-pills-home",
                            "aria-selected": "true",
                            children: "Ingredients"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-link mb-2",
                            id: "v-pills-profile-tab",
                            "data-bs-toggle": "pill",
                            "data-bs-target": "#v-pills-profile",
                            type: "button",
                            role: "tab",
                            "aria-controls": "v-pills-profile",
                            "aria-selected": "false",
                            children: "Facilities"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-link mb-2",
                            id: "v-pills-messages-tab",
                            "data-bs-toggle": "pill",
                            "data-bs-target": "#v-pills-messages",
                            type: "button",
                            role: "tab",
                            "aria-controls": "v-pills-messages",
                            "aria-selected": "false",
                            children: "Warnings"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-lg-8",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "tab-content",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tab-pane fade show active",
                            id: "v-pills-home",
                            role: "tabpanel",
                            "aria-labelledby": "v-pills-home-tab",
                            children: "No Ingredients Found"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tab-pane fade",
                            id: "v-pills-profile",
                            role: "tabpanel",
                            "aria-labelledby": "v-pills-profile-tab",
                            children: "No Facilities Found"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tab-pane fade",
                            id: "v-pills-messages",
                            role: "tabpanel",
                            "aria-labelledby": "v-pills-messages-tab",
                            children: "No Warnings Found"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const ProductSingle_AdditionalInfo = ((0,external_react_multi_lang_.withTranslation)(AdditionalInfo));

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "next/Link"
var Link_ = __webpack_require__(514);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/slices/cartSlice.js
var cartSlice = __webpack_require__(5586);
// EXTERNAL MODULE: ./components/Sections/products/AddToCart.js
var AddToCart = __webpack_require__(2106);
;// CONCATENATED MODULE: ./components/Sections/products/ProductSingle/BuyNow.js








const BuyNow = (props)=>{
    const { item  } = props;
    const [clicks, setClicks] = (0,external_react_.useState)(1);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const session = (0,react_.useSession)();
    const IncrementItem = ()=>{
        setClicks(clicks + 1);
    };
    const DecreaseItem = ()=>{
        clicks < 1 ? setClicks(0) : setClicks(clicks - 1);
    };
    const handleChange = (event)=>{
        setClicks(event.target.value);
    };
    const addToCartHandler = ()=>{
        const payload = {
            action: "plus",
            item: item
        };
        dispatch((0,cartSlice/* editCart */.Z8)(payload));
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_product-atc-form",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "qty-outter",
            children: /*#__PURE__*/ jsx_runtime_.jsx(AddToCart/* default */.Z, {
                style: "andro_btn-custom mb-3",
                item: item,
                children: "Buy Now"
            })
        })
    });
};
/* harmony default export */ const ProductSingle_BuyNow = (BuyNow);

// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
;// CONCATENATED MODULE: external "react-responsive-carousel"
const external_react_responsive_carousel_namespaceObject = require("react-responsive-carousel");
;// CONCATENATED MODULE: external "react-image-gallery"
const external_react_image_gallery_namespaceObject = require("react-image-gallery");
var external_react_image_gallery_default = /*#__PURE__*/__webpack_require__.n(external_react_image_gallery_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: ./node_modules/react-image-gallery/styles/css/image-gallery.css
var image_gallery = __webpack_require__(6279);
;// CONCATENATED MODULE: ./components/Sections/products/ProductSingle/ProductCarousel.js


 // requires a loader




// const ImageGallery = dynamic(() => import("react-image-gallery"), { ssr: false });

class ProductCarousel extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            images: [
                {
                    original: "../assets/img/products/7.png",
                    thumbnail: "../assets/img/products/7.png"
                },
                {
                    original: "../assets/img/products/7.png",
                    thumbnail: "../assets/img/products/7.png"
                },
                {
                    original: "../assets/img/products/7.png",
                    thumbnail: "../assets/img/products/7.png"
                }
            ]
        };
    }
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    className: "text-center"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_gallery_default()), {
                    items: this.state.images,
                    thumbnailPosition: "left",
                    showNav: false,
                    showFullscreenButton: false,
                    showPlayButton: false
                })
            ]
        });
    }
}

// EXTERNAL MODULE: ./helper/helper.js
var helper = __webpack_require__(8176);
;// CONCATENATED MODULE: ./components/Sections/products/ProductSingle/ProductDetails.js





const ProductDetails = (props)=>{
    const { item  } = props;
    console.log(item);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_product-single-controls andro_post-share",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                        href: "#",
                        className: "andro_add-to-favorite",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegHeart, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                        href: "#",
                        className: "andro_add-to-favorite",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCompressAlt, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "andro_rating-wrapper",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "andro_rating",
                    children: [
                        (0,helper/* Rating */.i)(item.rating),
                        " ",
                        item.rating,
                        " Stars"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                children: item.Item_Name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_product-price",
                children: [
                    item.price,
                    " 49 $"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "andro_product-excerpt mb-3",
                dangerouslySetInnerHTML: {
                    __html: item.Item_Desc
                }
            })
        ]
    });
};
/* harmony default export */ const ProductSingle_ProductDetails = (ProductDetails);

;// CONCATENATED MODULE: ./components/Sections/products/ProductSingle/ProductSingle.js


// import Relatedproduct from '../../layouts/Relatedproduct';
// import blogcategory from '../../../data/blogcategory.json';
// import blogtags from "../../../data/blogtags.json";






// import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
// import 'react-tabs/style/react-tabs.css';
// import { OverlayTrigger, Tooltip, Tab, Nav } from "react-bootstrap";
const ProductSingle = (props)=>{
    const { ItemDetails  } = props;
    const [item, setItem] = (0,external_react_.useState)(ItemDetails);
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-md-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ProductCarousel, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-md-7",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "andro_product-single-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ProductSingle_ProductDetails, {
                                                item: item
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ProductSingle_BuyNow, {
                                                item: item
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section pt-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "andro_product-additional-info",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ProductSingle_AdditionalInfo, {
                                item: item
                            })
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const ProductSingle_ProductSingle = ((0,external_react_multi_lang_.withTranslation)(ProductSingle));

// EXTERNAL MODULE: ./data/products.json
var products = __webpack_require__(7216);
// EXTERNAL MODULE: ./helper/auth.js
var auth = __webpack_require__(3182);
;// CONCATENATED MODULE: ./pages/products/[productSlug]/index.js








function Slug(props) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                breadcrumb: {
                    pagename: router.query.productSlug
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ProductSingle_ProductSingle, {
                ItemDetails: props.productDetails
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const productDetails = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/ECommerceSetting/getItemsDetails`, {
        method: "POST",
        headers: await (0,auth/* getAuthHeaders */.g)(),
        body: JSON.stringify({
            Item_Id: context.query.id,
            lang: "ar"
        })
    });
    const details = await productDetails.json();
    return {
        props: {
            productDetails: details[0]
        }
    };
};
/* harmony default export */ const _productSlug_ = ((0,external_react_multi_lang_.withTranslation)(Slug));


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("next/Link");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4243:
/***/ ((module) => {

module.exports = require("react-multi-lang");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,668,946,586,106,216], () => (__webpack_exec__(146)));
module.exports = __webpack_exports__;

})();