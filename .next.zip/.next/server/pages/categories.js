"use strict";
(() => {
var exports = {};
exports.id = 161;
exports.ids = [161];
exports.modules = {

/***/ 2903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ categories),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
// EXTERNAL MODULE: ./components/layout/Reusable/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(6946);
// EXTERNAL MODULE: external "react-multi-lang"
var external_react_multi_lang_ = __webpack_require__(4243);
// EXTERNAL MODULE: ./data/category.json
var category = __webpack_require__(5635);
// EXTERNAL MODULE: external "next/Link"
var Link_ = __webpack_require__(514);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
;// CONCATENATED MODULE: ./pages/categories/index.js







const pagelocation = "Categories";
class Index extends external_react_.Component {
    constructor(props){
        super(props);
    }
    render() {
        const { CategoryList  } = this.props;
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                    breadcrumb: {
                        pagename: pagelocation
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: CategoryList && CategoryList.length > 0 ? CategoryList.map((cat, index)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-4 col-xs-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "card catg_card",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "card-img-top",
                                                src: `assets/img/products/${index + 1}.png`,
                                                alt: "Card image cap"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "card-body",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "card-title",
                                                        children: cat.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "card-text",
                                                        children: "Some quick example text to build on the card title and make up the bulk of the cards content."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "categories/" + cat.slug,
                                                        className: "agri-btn-rounded primary",
                                                        children: this.props.t("Products.ShopNow")
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, index);
                            }) : null
                        })
                    })
                })
            ]
        });
    }
}
const getStaticProps = async ()=>{
    return {
        props: {
            CategoryList: category
        }
    };
};
/* harmony default export */ const categories = ((0,external_react_multi_lang_.withTranslation)(Index));


/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("next/Link");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4243:
/***/ ((module) => {

module.exports = require("react-multi-lang");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5635:
/***/ ((module) => {

module.exports = JSON.parse('[{"icon":"flaticon-diet","title":"Food","slug":"Agri-food"},{"icon":"flaticon-supplements","title":"Supplements","slug":"Agri-food"},{"icon":"flaticon-groceries","title":"Baskets","slug":"Agri-basket"},{"icon":"flaticon-cleaning-spray","title":"Home Care","slug":"Agri-Cleaning"},{"icon":"flaticon-baby","title":"Kids Care","slug":"Agri-Kids"},{"icon":"flaticon-olive-oil","title":"Oils","slug":"Agri-Oils"}]');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [946], () => (__webpack_exec__(2903)));
module.exports = __webpack_exports__;

})();