"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 397:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "authOptions": () => (/* binding */ authOptions),
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: ./services/AuthenticationAPI.js
class AuthenticationAPI {
    async Register(reqBody) {
        const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/Auth/Register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(reqBody)
        });
        const result = await res.json();
        return result;
    }
    async Login(reqBody) {
        const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/Auth/Login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: reqBody.email,
                password: reqBody.password,
                rememberMe: reqBody.rememberMe
            })
        });
        const result = await res.json();
        console.log(result);
        return result;
    }
}

;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js



// import Provider from "next-auth/providers";
const authApi = new AuthenticationAPI();
const authOptions = {
    session: {
        strategy: "jwt"
    },
    pages: {
        signIn: "/login",
        error: "/login"
    },
    providers: [
        credentials_default()({
            name: "credentials",
            async authorize (credentials, req) {
                const reqBody = {
                    email: credentials.email,
                    password: credentials.password,
                    rememberMe: true
                };
                const res = await authApi.Login(reqBody);
                if (res.token) {
                    return {
                        email: credentials.email,
                        name: res.token
                    };
                }
                throw new Error("Incorrect Credentials");
            }
        })
    ],
    callbacks: {
        async session ({ session , token , user  }) {
            session.user.id = token.id;
            session.accessToken = token.accessToken;
            return session;
        },
        async jwt ({ token , user , account , profile , isNewUser  }) {
            if (user) {
                token.id = user.id;
            }
            if (account) {
                token.accessToken = account.access_token;
            }
            return token;
        }
    }
};
/* harmony default export */ const _nextauth_ = (external_next_auth_default()(authOptions));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(397));
module.exports = __webpack_exports__;

})();