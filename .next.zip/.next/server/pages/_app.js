(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// NAMESPACE OBJECT: ./helper/auth.js
var auth_namespaceObject = {};
__webpack_require__.r(auth_namespaceObject);
__webpack_require__.d(auth_namespaceObject, {
  "b": () => (getAuthToken),
  "y": () => (getTokenDuration)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-multi-lang"
var external_react_multi_lang_ = __webpack_require__(4243);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(1598);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
;// CONCATENATED MODULE: ./helper/auth.js
function getTokenDuration() {
    if (false) {}
}
function getAuthToken() {
    if (false) {}
}

;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
;// CONCATENATED MODULE: ./redux/slices/cartSlice.js

const cartSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "cart",
    initialState: {
        items: [],
        total: 0,
        currency: "$"
    },
    extraReducers: (builder)=>{
        builder.addCase(getCartDetails.fulfilled, (state, { payload  })=>{
            state.items = payload.items;
            state.total = payload.total;
        });
        builder.addCase(editCart.fulfilled, (state, { payload  })=>{
            state.items = payload.items;
            state.total = payload.total;
        });
    }
});
const getCartDetails = (0,toolkit_namespaceObject.createAsyncThunk)("cart/getCartDetails", async ()=>{
    const data = {
        items: [
            {
                id: 1,
                img: "assets/img/products/1.png",
                title: "Kiwi",
                qty: 2,
                price: 12.99
            },
            {
                id: 2,
                img: "assets/img/products/2.png",
                title: "Watermelons",
                qty: 1,
                price: 12.99
            },
            {
                id: 3,
                img: "assets/img/products/3.png",
                title: "Cucumbers",
                qty: 3,
                price: 12.99
            },
            {
                id: 4,
                img: "assets/img/products/3.png",
                title: "Cucumbers",
                qty: 3,
                price: 12.99
            }
        ],
        total: 99,
        currency: "$"
    };
    return data;
});
const editCart = (0,toolkit_namespaceObject.createAsyncThunk)("cart/editCart", async ()=>{
// fetch api to edit the cart details
// the return of the api will be the new cart details
// return the cart details that came from the database
});
const cartActions = cartSlice.actions;
/* harmony default export */ const slices_cartSlice = (cartSlice);

// EXTERNAL MODULE: external "next/Link"
var Link_ = __webpack_require__(514);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/layout/Reusable/BrandLogo.js


const BrandLogo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
        className: "navbar-brand",
        href: "/",
        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: "../img/logo.png",
            alt: "logo"
        })
    });
};
/* harmony default export */ const Reusable_BrandLogo = (BrandLogo);

;// CONCATENATED MODULE: ./components/layout/Footer/Footer.js






class Footer extends external_react_.Component {
    scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
            className: "footer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer-top",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Reusable_BrandLogo, {})
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "footer-middle",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-xl-3 col-lg-3 col-md-4 col-sm-12 footer-widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "widget-title",
                                            children: this.props.t("Footer.Information")
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/",
                                                        children: "Home"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/blog-grid",
                                                        children: "Blog"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/about",
                                                        children: "About Us"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/shop-v1",
                                                        children: "Shop"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/contact",
                                                        children: "Contact Us"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-3 col-lg-3 col-md-4 col-sm-12 footer-widget",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "widget-title",
                                        children: this.props.t("Footer.TopCategories")
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-xl-3 col-lg-3 col-md-4 col-sm-12 footer-widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "widget-title",
                                            children: this.props.t("Footer.Others")
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/checkout",
                                                        children: "Checkout"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/cart",
                                                        children: "Cart"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/product-single",
                                                        children: "Product"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/shop-v1",
                                                        children: "Shop"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "/legal",
                                                        children: "Legal"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-xl-3 col-lg-3 col-md-6 col-sm-12 footer-widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "widget-title",
                                            children: this.props.t("Footer.SocialMedia")
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "social-media",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "#",
                                                        className: "facebook",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "#",
                                                        className: "google",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaYoutube, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "#",
                                                        className: "twitter",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {})
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "footer-bottom",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "container",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "#",
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "#",
                                            children: "Refund Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "#",
                                            children: "Cookie Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "#",
                                            children: "Terms & Conditions"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "footer-copyright",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            "Copyright \xa9 2023 ",
                                            /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                href: "#",
                                                children: "RTS"
                                            }),
                                            " All Rights Reserved."
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        href: "#",
                                        className: "back-to-top",
                                        onClick: ()=>this.scrollToTop(),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaHandPointer, {})
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const Footer_Footer = ((0,external_react_multi_lang_.withTranslation)(Footer));

;// CONCATENATED MODULE: ./services/CategoryAPI.js

class CategoryApi {
    authToken = getAuthToken();
    async GetCategoriesMenu() {
        const res = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/ECommerceSetting/GetCategoriesMenu`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: this.authToken
            },
            body: JSON.stringify({
                lang: "ar",
                FAClassification_ParentId: 81
            })
        });
        const data = await res.json();
        return data;
    }
    async fetchCategoryProducts(lang, cate_id) {
        const response = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/ECommerceSetting/getItemMainByCategory`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                lang: "ar",
                Cate_Id: cate_id,
                limit: 6,
                start: 1
            })
        });
        const data = await response.json();
        return data;
    }
}

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/Navigation/CategoryNavItem.js




const CategoryNavItem = (props)=>{
    const { link , isChild  } = props;
    const [subMenuIsShown, setSubMenuIsShown] = (0,external_react_.useState)(false);
    const itemStyle = link.ClassificationChildren.length > 0 ? "menu-item-has-children" : "";
    const itemLink = link.ClassificationChildren.length > 0 ? `/categories/${"mopidat"}?id=${link.FAClassificationId}` : `/categories/${"organic"}?id=${link.FAClassificationId}`;
    // const itemLink = `/categories/${link.FAClassificationSlug}?&id=${
    //   link.FAClassificationId
    // }`;
    const arrowClickHandler = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setSubMenuIsShown(!subMenuIsShown);
    };
    const blurHandler = ()=>{
        setSubMenuIsShown(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: `menu-item ${itemStyle}`,
        onMouseLeave: blurHandler,
        onClick: blurHandler,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                href: itemLink,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "ms-2",
                        src: `data:image/png;base64,${link.Icon}`,
                        width: "16",
                        height: "16"
                    }),
                    link.FAClassificationName,
                    link.ClassificationChildren.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        onClick: arrowClickHandler,
                        className: "icon",
                        children: [
                            !isChild && (!subMenuIsShown ? /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleDown, {}) : /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleUp, {})),
                            isChild && (!subMenuIsShown ? /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleRight, {}) : /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleLeft, {}))
                        ]
                    })
                ]
            }),
            subMenuIsShown && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "sub-menu",
                role: "menu",
                children: link.ClassificationChildren.map((subItem)=>/*#__PURE__*/ jsx_runtime_.jsx(CategoryNavItem, {
                        link: subItem,
                        isChild: true
                    }, subItem.FAClassificationId))
            })
        ]
    });
};
/* harmony default export */ const Navigation_CategoryNavItem = (CategoryNavItem);

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/Navigation/HeaderNavItem.js


const HeaderNavItem = (props)=>{
    const { link  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(Navigation_CategoryNavItem, {
        link: link
    });
};
/* harmony default export */ const Navigation_HeaderNavItem = (HeaderNavItem);

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/Navigation/HeaderNav.js





const CategoryAPI = new CategoryApi();
const HeaderNav = (props)=>{
    const { lang  } = props;
    const [navLinks, setNavLinks] = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        const getNavLinks = async ()=>{
            const data = await CategoryAPI.GetCategoriesMenu();
            setNavLinks(data.slice(0, 4));
        };
        getNavLinks();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "header-nav",
        children: navLinks.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx(Navigation_HeaderNavItem, {
                lang: lang,
                link: link
            }, link.FAClassificationId))
    });
};
/* harmony default export */ const Navigation_HeaderNav = ((0,external_react_multi_lang_.withTranslation)(HeaderNav));

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/SideCategoriesList.js




const SideCategoriesList_CategoryAPI = new CategoryApi();
const SideCategoriesList = ()=>{
    const [categories, setCategories] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        const getCategories = async ()=>{
            const categories = await SideCategoriesList_CategoryAPI.GetCategoriesMenu();
            setCategories(categories);
        };
        getCategories();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar d-block",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sidebar-widget widget-categories-icons",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "widget-title",
                        children: "Popular Categories"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sidebar-widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "widget-title",
                        children: "Popular Tags"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tagcloud",
                        children: categories && categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                href: `/categories/${category.FAClassificationSlug}?id=${category.FAClassificationId}`,
                                children: category.FAClassificationName
                            }, category.FAClassificationId))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Reusable_SideCategoriesList = (SideCategoriesList);

;// CONCATENATED MODULE: external "classnames"
const external_classnames_namespaceObject = require("classnames");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_namespaceObject);
;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderBottom/SideCategoriesToggler.js




const SideCategoriesToggler = (props)=>{
    const [showSideCategoriesTags, setShowSideCategoriesTags] = (0,external_react_.useState)();
    const toggleSideCategoriesTags = ()=>setShowSideCategoriesTags(!showSideCategoriesTags);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("aside", {
                className: external_classnames_default()("andro_aside andro_aside-right", {
                    open: showSideCategoriesTags
                }),
                children: /*#__PURE__*/ jsx_runtime_.jsx(Reusable_SideCategoriesList, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "andro_aside-overlay aside-trigger-right",
                onClick: toggleSideCategoriesTags
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "aside-toggler aside-trigger-right desktop-toggler",
                onClick: toggleSideCategoriesTags,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                ]
            })
        ]
    });
};
/* harmony default export */ const HeaderBottom_SideCategoriesToggler = (SideCategoriesToggler);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderBottom/HeaderOffers.js





const Offers = [
    {
        title: "Cash On Delivery",
        icon: "icon.png"
    },
    {
        title: "Free Shipping",
        icon: "icon.png"
    },
    {
        title: "Free Refund",
        icon: "icon.png"
    }
];
function HeaderOffers() {
    const [data, setData] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        async function fetchData() {
            // const res = await fetch(
            //   'https://proton.api.atomicassets.io/atomicmarket/v1/sales'
            // );
            const data = Offers;
            setData(data);
        }
        fetchData();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        children: data && data.map((offer, index)=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "../img/" + offer.icon,
                        alt: "ecommerce",
                        width: "16",
                        height: "16"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                        href: "#",
                        children: offer.title
                    })
                ]
            }, index);
        })
    });
}
/* harmony default export */ const HeaderBottom_HeaderOffers = ((0,external_react_multi_lang_.withTranslation)(HeaderOffers));

;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderBottom/HeaderBottom.js




const HeaderBottom = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "main_header-bottom",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "main_header-bottom-inner mt-0",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "d-flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(HeaderBottom_SideCategoriesToggler, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(Navigation_HeaderNav, {
                            lang: props.lang
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "header_left_offers",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderBottom_HeaderOffers, {})
                })
            ]
        })
    });
};
/* harmony default export */ const HeaderBottom_HeaderBottom = (HeaderBottom);

;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderMiddle/LanguageChange.js




const LanguageChange = (props)=>{
    const [language, setLanguage] = (0,external_react_.useState)(props.lang);
    const changeLang = (lang)=>{
        setLanguage(lang);
        props.changeLang(lang);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "language-change",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            className: "menu-item menu-item-has-children",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                    href: "",
                    children: props.t("Navbar." + language)
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "sub-menu sub-menu-left",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            onClick: ()=>changeLang("en"),
                            children: props.t("Navbar.en")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            onClick: ()=>changeLang("ar"),
                            children: props.t("Navbar.ar")
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const HeaderMiddle_LanguageChange = ((0,external_react_multi_lang_.withTranslation)(LanguageChange));

;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderMiddle/HeaderControls/MobileViewNavToggler.js






const categoryApi = new CategoryApi();
const MobileViewNavToggler = (props)=>{
    const [navIsShown, setNavIsShown] = (0,external_react_.useState)(false);
    const clickHandler = ()=>setNavIsShown(!navIsShown);
    const [categories, setCategories] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        const getCategories = async ()=>{
            const categories = await categoryApi.GetCategoriesMenu();
            setCategories(categories);
        };
        getCategories();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "aside-toggler aside-trigger-left",
                onClick: clickHandler,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                ]
            }),
            navIsShown && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mobilemenu-overlay",
                onClick: clickHandler,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mobile_nav",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "text-center text-white",
                            children: "Categories"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tagcloud",
                            children: categories && categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                    href: `/categories/${category.FAClassificationSlug}?id=${category.FAClassificationId}`,
                                    children: category.FAClassificationName
                                }, category.FAClassificationId))
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const HeaderControls_MobileViewNavToggler = (MobileViewNavToggler);

;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderMiddle/HeaderControls/HeaderControls.js







const HeaderControls = (props)=>{
    const cartState = (0,external_react_redux_.useSelector)((state)=>state.cart);
    // Start watching the size to unmount the mobile navigation from the dom completely in desktop view
    const [isMobileView, setIsMobileView] = (0,external_react_.useState)(false);
    const updateWindowSize = ()=>{
        setIsMobileView(window.innerWidth < 991);
    };
    (0,external_react_.useEffect)(()=>{
        updateWindowSize();
        window.addEventListener("resize", updateWindowSize);
        return ()=>{
            window.removeEventListener("resize", updateWindowSize);
        };
    }, []);
    // End watching the size to unmount the mobile navigation from the dom completely in desktop view
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "main_header-controls",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "main_header-controls-inner",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "main_header-favorites",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: "/chat",
                            title: "Chat",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCommentAlt, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "main_header-favorites",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: "/login",
                            title: "Login",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaUserAlt, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "main_header-favorites",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: "/wishlist",
                            title: "Wish List",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegHeart, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "main_header-cart",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                            href: "/cart",
                            title: "Cart",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaShoppingBasket, {}),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "main_header-cart-content fs-800",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                cartState.items.length,
                                                " Items"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                cartState.total,
                                                " ",
                                                cartState.currency
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderMiddle_LanguageChange, {
                        changeLang: props.changeLang,
                        lang: props.lang
                    })
                ]
            }),
            isMobileView && /*#__PURE__*/ jsx_runtime_.jsx(HeaderControls_MobileViewNavToggler, {})
        ]
    });
};
/* harmony default export */ const HeaderControls_HeaderControls = (HeaderControls);

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/HeaderSearchForm/HeaderSearchFormLabel.js

const HeaderSearchFromLabel = (props)=>{
    return /*#__PURE__*/ _jsxs("label", {
        children: [
            /*#__PURE__*/ _jsx("input", {
                type: "checkbox",
                name: props.name,
                defaultValue: props.defaultValue
            }),
            props.title,
            /*#__PURE__*/ _jsx("i", {
                className: "fas fa-check"
            })
        ]
    });
};
/* harmony default export */ const HeaderSearchFormLabel = ((/* unused pure expression or super */ null && (HeaderSearchFromLabel)));

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/HeaderSearchForm/HeaderSearchFormLabelList.js



const HeaderSearchFormLabelList = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_search-adv-cats",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
            children: [
                "All ",
                /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleDown, {})
            ]
        })
    });
};
/* harmony default export */ const HeaderSearchForm_HeaderSearchFormLabelList = (HeaderSearchFormLabelList);

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/HeaderSearchForm/HeaderSearchForm.js



const HeaderSearchForm = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_search-adv",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(HeaderSearchForm_HeaderSearchFormLabelList, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "andro_search-adv-input",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            className: "form-control",
                            placeholder: "Look for Fruits, Vegetables",
                            name: "search"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            name: "button",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaSearch, {})
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const HeaderSearchForm_HeaderSearchForm = (HeaderSearchForm);

;// CONCATENATED MODULE: ./components/layout/MainHeader/HeaderMiddle/HeaderMiddle.js





const HeaderMiddle = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "main_header-middle",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: "navbar",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Reusable_BrandLogo, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderSearchForm_HeaderSearchForm, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderControls_HeaderControls, {
                        changeLang: props.changeLang,
                        lang: props.lang
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const HeaderMiddle_HeaderMiddle = (HeaderMiddle);

;// CONCATENATED MODULE: ./components/layout/MainHeader/Reusable/ToggleNav.js


const ToggleNav = (props)=>{
    return /*#__PURE__*/ _jsx("div", {
        className: "andro_aside-overlay aside-trigger-left"
    });
};
/* harmony default export */ const Reusable_ToggleNav = ((/* unused pure expression or super */ null && (ToggleNav)));

;// CONCATENATED MODULE: ./components/layout/MainHeader/MainHeader.js





const MainHeader = (props)=>{
    const [isTop, setIsTop] = (0,external_react_.useState)(true);
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
            className: `main_header`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(HeaderMiddle_HeaderMiddle, {
                    changeLang: props.changeLang,
                    lang: props.lang
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(HeaderBottom_HeaderBottom, {
                    lang: props.lang
                })
            ]
        })
    });
};
/* harmony default export */ const MainHeader_MainHeader = (MainHeader);

;// CONCATENATED MODULE: ./components/layout/MainLayout.js







function MainLayout(props) {
    const dispatch = (0,external_react_redux_.useDispatch)();
    const token = getAuthToken();
    const changeLang = (lang)=>{
        props.changeLang(lang);
    };
    (0,external_react_.useEffect)(()=>{
        dispatch(getCartDetails());
        if (!token) {
            return;
        }
        if (token === "EXPIRED") {
            localStorage.removeItem("Agri_Token");
            localStorage.removeItem("Agri_Expiration");
            return;
        }
        const tokenDuration = getTokenDuration();
        setTimeout(()=>{
            localStorage.removeItem("Agri_Token");
            localStorage.removeItem("Agri_Expiration");
        }, tokenDuration);
    }, [
        token
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MainHeader_MainHeader, {
                changeLang: changeLang,
                lang: props.lang
            }),
            props.children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {
                footer: {
                    style: "",
                    logo: "img/logo.png"
                }
            })
        ]
    });
}

;// CONCATENATED MODULE: ./redux/slices/authSlice.js


const authSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "auth",
    initialState: {
        isAuthenticated: false
    },
    extraReducers: (builder)=>{
        builder.addCase(checkAuthentication.fulfilled, (state, { payload  })=>{
            state.isAuthenticated = payload;
        });
    }
});
const checkAuthentication = (0,toolkit_namespaceObject.createAsyncThunk)("auth/checkAuthentication", async ()=>{
    const authToken = (0,auth_namespaceObject["default"])();
    // Call api to check the validity of the token
    if (authToken) {
        return true;
    }
    return false;
});
/* harmony default export */ const slices_authSlice = (authSlice);

;// CONCATENATED MODULE: ./redux/store.js



const store = (0,toolkit_namespaceObject.configureStore)({
    reducer: {
        cart: slices_cartSlice.reducer,
        auth: slices_authSlice.reducer
    }
});
/* harmony default export */ const redux_store = (store);

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/homeBanner.css
var homeBanner = __webpack_require__(3360);
// EXTERNAL MODULE: ./styles/sass/main.css
var main = __webpack_require__(4495);
// EXTERNAL MODULE: ./styles/style.css
var style = __webpack_require__(8702);
;// CONCATENATED MODULE: ./translations/ar.json
const ar_namespaceObject = JSON.parse('{"Navbar":{"Lang":"اللغه","en":"(EN)","ar":"(AR)","MyAccount":"حسابي","AllCategories":"كل الاقسام","Categories":"الاقسام","Search":"بحث","YourCart":"عربة التسوق","WishList":"المفضلة","Home":"الصفحة الرسمية","About":"نبذه عن","Shop":"المتجر","ContactUs":"تواصل معنا","Chat":"دردشة عامة"},"Home":{"JoinChat":"الانضمام للدردشة"},"Products":{"BestProducts":"أفضل المنتجات","AddToCart":"أضف الي العربة","ViewDetails":"رؤية التفاصيل","Stars":"نجوم","Featured":"مميز","BooksAndInfo":"كتب ومعلومات زراعية","ReadMore":"قراءة المزيد","ViewAll":"رؤية الجميع","ShopNow":"اشتري الان","Sort":"ترتيب حسب","Compare":"مقارنة","AddToWish":"أضف الي المفضلة","Brand":"الماركة","UOM":"وحده القياس","AddInfo":"معلومات اضافية","reviews":"تقييم مستخدمين"},"Footer":{"TopCategories":"أعلي الاقسام","Others":"اخري","SocialMedia":"وسائل التواصل","Signup":"تسجيل الدخول","Information":"المعلومات"},"Cart":{"Product":"المنتج","Price":"السعر","Quantity":"الكمية","Total":"الإجمالي","CartTotal":"الإجمالي","EnterCoupon":"أدخل كود الخصم","Tax":"ضرائب","CheckoutProceed":"قم بالدفع","AddToCart":"أضف الي العربة"},"Wishlist":{"Availability":"المتاح","Actions":"إختيارات","InStock":"متاح","OutOfStock":"تم نفاذ الكمية","Share":"شارك رغباتك"},"Checkout":{"BillingDetails":"تفاصيل الفاتورة","Firstname":"الاسم الاول","Lastname":"اسم العائلة","CompanyName":"Company Name","Country":"الدولة","StAddress1":"العنوان الأول","StAddress2":"العنوان الثاني","TownCity":"المدينة","Phone":"رقم الهاتف","Email":"البريد الالكتروني","Notes":"Order Notes","Postal":"الرقم البريدي","Optional":"إختياري","Card":"رقم البطاقة","FullName":"إسم حامل البطاقة","Expiry":"تاريخ انتهاء البطاقة","PlaceOrder":"نفّذ الطلب","PaymentChoose":"إختر طريقة الدفع","CreditCard":"بطاقة الإئتمان","Paypal":"باي بال","OnDelivery":"عند الإستلام"},"Categories":{"Ingrediants":"المكونات الزراعية","Organic":"المنتجات العضوية","Farms":"منتجات المزارع","Supplements":"المكملات"}}');
;// CONCATENATED MODULE: ./translations/en.json
const en_namespaceObject = JSON.parse('{"Navbar":{"Lang":"Language","en":"(EN)","ar":"(AR)","MyAccount":"My Account","AllCategories":"All Categories","Categories":"Categories","Search":"Search","YourCart":"Your Cart","WishList":"WishList","Home":"Home","About":"About","Shop":"Shop","ContactUs":"Contact Us","Chat":"Chat"},"Home":{"JoinChat":"Join Chat"},"Products":{"BestProducts":"Best Products","AddToCart":"Add To Cart","AddToWish":"Add To WishList","ViewDetails":"View Details","Stars":"Stars","Featured":"Featured","BooksAndInfo":"Books And Agriculture Info","ReadMore":"Read More","ViewAll":"View All","ShopNow":"Shop Now","Sort":"Sort","Compare":"Compare","Brand":"Brand","UOM":"UOM","AddInfo":"Additional Information","reviews":"reviews","ItemDesc":"Item Description"},"Footer":{"TopCategories":"Top Categories","Others":"Others","SocialMedia":"Social Media","Signup":"Signup","Information":"Information"},"Cart":{"Product":"Product","Price":"Price","Quantity":"Quantity","Total":"Total","CartTotal":"Cart Total","EnterCoupon":"Enter Coupon Code","Tax":"Tax","CheckoutProceed":"PROCEED TO CHECKOUT","AddToCart":"ADD TO CART"},"Wishlist":{"Availability":"Availability","Actions":"Actions","InStock":"In Stock","OutOfStock":"Out Of Stock","Share":"Share Your Wishlist"},"Checkout":{"BillingDetails":"BillingDetails","Firstname":"First Name","Lastname":"Last Name","CompanyName":"Company Name","Country":"Country","StAddress1":"Street Address 1","StAddress2":"Street Address 2","TownCity":"Town / City","Phone":"Phone Number","Email":"Email Address","Notes":"Order Notes","Postal":"Postal Code","Optional":"Optional","Card":"Card Number","FullName":"Full Name","Expiry":"Expiry Date","PlaceOrder":"PLACE ORDER","PaymentChoose":"Choose Payment Method","CreditCard":"Credit Card","Paypal":"PayPal","OnDelivery":"On Delivery"},"Categories":{"Ingrediants":"Ingrediants","Organic":"Organic","Farms":"Farms","Supplements":"Supplements"}}');
;// CONCATENATED MODULE: ./pages/_app.js














(0,external_react_multi_lang_.setTranslations)({
    ar: ar_namespaceObject,
    en: en_namespaceObject
});
(0,external_react_multi_lang_.setDefaultLanguage)("en");
function App({ Component , pageProps  }) {
    const [lang, setLang] = (0,external_react_.useState)("en");
    const changeLang = (0,external_react_.useCallback)((lang)=>{
        setLang(lang);
        (0,external_react_multi_lang_.setDefaultLanguage)(lang);
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
            store: redux_store,
            children: /*#__PURE__*/ jsx_runtime_.jsx(MainLayout, {
                changeLang: changeLang,
                lang: lang,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        })
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3360:
/***/ (() => {



/***/ }),

/***/ 4495:
/***/ (() => {



/***/ }),

/***/ 8702:
/***/ (() => {



/***/ }),

/***/ 514:
/***/ ((module) => {

"use strict";
module.exports = require("next/Link");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 4243:
/***/ ((module) => {

"use strict";
module.exports = require("react-multi-lang");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,121,511], () => (__webpack_exec__(5154)));
module.exports = __webpack_exports__;

})();