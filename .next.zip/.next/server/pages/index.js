"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 5050:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/Link"
var Link_ = __webpack_require__(514);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-multi-lang"
var external_react_multi_lang_ = __webpack_require__(4243);
// EXTERNAL MODULE: ./data/category.json
var category = __webpack_require__(5635);
;// CONCATENATED MODULE: ./components/Sections/home/Category.js





const Category = (props)=>{
    const [data, setData] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        async function fetchData() {
            const data = category;
            setData(data);
        }
        fetchData();
    }, []);
    console.log("data ", data);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: data && data.map((cat, index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: `menu-item ${cat.child ? "menu-item-has-children" : ""} `,
                children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                    href: "#",
                    children: cat.title
                })
            }, index);
        })
    });
};
/* harmony default export */ const home_Category = ((0,external_react_multi_lang_.withTranslation)(Category));

;// CONCATENATED MODULE: ./components/Sections/home/HomeAdvertiseSlider.js



const settings = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    dotsClass: "slick-dots d-flex",
    // autoplay: true,
    variableWidth: true
};
function HomeAdvertiseSlider() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
        className: "advertise-slider",
        ...settings,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "advertise",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "../img/agri_banner.png",
                        alt: ""
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "advertise",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "../img/slider.jpg",
                        alt: ""
                    })
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Sections/home/chat_banner.js



function chat_banner(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-lg-2",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "chat_banner",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "card-header",
                        children: "Room Title"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "card-body text-success",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "card-text",
                            children: "Some quick example text to build on the card title and make up the bulk of the cards content."
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "card-footer",
                        children: props.t("Home.JoinChat")
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const home_chat_banner = ((0,external_react_multi_lang_.withTranslation)(chat_banner));

;// CONCATENATED MODULE: ./components/Sections/home/ProductSlider.js



const bannerslider = [
    {
        photo: "../img/products/2.png",
        couponcode: "ORGANIC991",
        title: "40% Sale",
        titlespan: "On Select Products",
        para: "Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Sed porttitor lectus nibh. Vestibulum ac diam sit"
    },
    {
        photo: "../img/products/12.png",
        couponcode: "ORGANIC991",
        title: "40% Sale",
        titlespan: "On Select Products",
        para: "Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Sed porttitor lectus nibh. Vestibulum ac diam sit"
    }
];
const sliderSettings = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: true,
    dotsClass: "slick-dots d-flex",
    autoplay: true,
    responsive: [
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 1
            }
        },
        {
            breakpoint: 575,
            settings: {
                slidesToShow: 1
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 1
            }
        }
    ]
};
const ProductsSlider = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-lg-6 col-xs-12",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "andro_banner banner-1",
            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                className: "andro_banner-slider",
                ...sliderSettings,
                children: bannerslider.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container-fluid",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row align-items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                "Use code ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    className: "custom-primary",
                                                    children: item.couponcode
                                                }),
                                                " during checkout"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                            children: [
                                                " ",
                                                item.title,
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "fw-400",
                                                    children: item.titlespan
                                                }),
                                                " "
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: item.para
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "/shop-v1",
                                            className: "andro_btn-custom",
                                            children: "Shop Now"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-6 d-none d-lg-block",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "../" + item.photo,
                                        alt: item.title
                                    })
                                })
                            ]
                        })
                    }, i))
            })
        })
    });
};
/* harmony default export */ const ProductSlider = (ProductsSlider);

;// CONCATENATED MODULE: ./components/Sections/home/Other.js


const Other = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-lg-2 col-xs-12",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "andro_banner other_banner",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "../img/advertise.png",
                    alt: "agriculture_advertise"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "../img/video.png",
                    alt: "agriculture_advertise",
                    style: {
                        marginTop: "10px"
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "../img/advertise.png",
                    alt: "agriculture_advertise",
                    style: {
                        marginTop: "10px"
                    }
                })
            ]
        })
    });
};
/* harmony default export */ const home_Other = ((0,external_react_multi_lang_.withTranslation)(Other));

;// CONCATENATED MODULE: ./components/Sections/home/Home_Offer.js



function Home_Offer(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-lg-2 col-xs-12",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "andro_banner offer_banner",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "offer_banner",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card mb-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card-header",
                            children: "Special Offers"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card-body text-success",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "../img/offer.jpeg"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card-footer",
                            children: props.t("Products.ViewAll")
                        })
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const home_Home_Offer = ((0,external_react_multi_lang_.withTranslation)(Home_Offer));

;// CONCATENATED MODULE: ./components/Sections/home/HomeBanner.js












class HomeBanner extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "section carousel_bg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "home-banner",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeAdvertiseSlider, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "home-banner--content",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container-fluid",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(home_chat_banner, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ProductSlider, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(home_Other, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(home_Home_Offer, {})
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const home_HomeBanner = ((0,external_react_multi_lang_.withTranslation)(HomeBanner));

;// CONCATENATED MODULE: ./components/Sections/home/BestProducts/BestProducts.js






const BestProducts_settings = {
    slidesToShow: 6,
    slidesToScroll: 1,
    arrows: false,
    dots: false,
    // autoplay: true,
    responsive: [
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 1
            }
        },
        {
            breakpoint: 575,
            settings: {
                slidesToShow: 1
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2
            }
        }
    ]
};
class BestProducts extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            modalshow: false
        };
    }
    next = ()=>{
        this.slider.slickNext();
    };
    previous = ()=>{
        this.slider.slickPrev();
    };
    // Modal
    modalShow = ()=>{
        this.setState({
            modalshow: true
        });
    };
    modalClose = ()=>{
        this.setState({
            modalshow: false
        });
    };
    Rating = (rating)=>{
        let stars = [];
        for(let i = 0; i < 5; i++){
            stars.push(/*#__PURE__*/ jsx_runtime_.jsx(fa_.FaStar, {}, i));
        }
        if (rating && rating > 0) {
            for(let i1 = 0; i1 <= rating - 1; i1++){
                stars[i1] = /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaStar, {
                    className: "active"
                }, i1);
            }
        }
        return stars;
    };
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "section pt-0 andro_fresh-arrivals",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "section-title flex-title",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "title",
                                children: this.props.t("Products.BestProducts")
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "andro_arrows",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "slick-arrow slider-prev",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaArrowLeft, {
                                            onClick: this.previous
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "slick-arrow slider-prev",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaArrowRight, {
                                            onClick: this.next
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                        className: "andro_fresh-arrivals-slider",
                        ref: (c)=>this.slider = c,
                        ...BestProducts_settings,
                        children: this.props.ProductList && this.props.ProductList.length > 0 ? this.props.ProductList.map((item, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "andro_product andro_product-has-controls andro_product-has-buttons",
                                children: [
                                    item.featured === true ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "andro_product-badge andro_badge-featured",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaStar, {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: this.props.t("Products.Featured")
                                            })
                                        ]
                                    }) : "",
                                    item.discount > 0 || item.discount !== "" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "andro_product-badge andro_badge-sale",
                                        children: [
                                            item.discount,
                                            "% Off"
                                        ]
                                    }) : "",
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "andro_product-thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            href: "/products" + item.slug,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: item.img,
                                                alt: item.title
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "andro_product-body",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "category_badge",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "badge badge-secondary ",
                                                    children: item.CategoryName
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    className: "text-dark",
                                                    href: "/products/" + item.slug,
                                                    children: item.title
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "andro_product-price",
                                                children: [
                                                    item.discount > 0 || item.discount !== "" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            new Intl.NumberFormat().format((item.price * (100 - item.discount) / 100).toFixed(2)),
                                                            "$"
                                                        ]
                                                    }) : "",
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            new Intl.NumberFormat().format(item.price.toFixed(2)),
                                                            "$"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: item.shortdesc
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "andro_rating-wrapper",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "andro_rating",
                                                        children: this.Rating(item.rating)
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            item.rating,
                                                            this.props.t("Products.Stars")
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "andro_product-footer",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "andro_product-buttons",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    href: "/products/" + item.slug,
                                                    className: "andro_btn-custom primary",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaShoppingBasket, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    href: "/products/" + item.slug,
                                                    className: "andro_btn-custom light",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegEye, {})
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }, i)) : null
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const BestProducts_BestProducts = ((0,external_react_multi_lang_.withTranslation)(BestProducts));

;// CONCATENATED MODULE: ./components/Sections/home/Cta.js



class Cta extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "andro_cta-notice secondary-bg pattern-bg",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "andro_cta-notice-inner",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "text-white",
                            children: "Buy Today and Get 20% Off"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-white",
                            children: "Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum porta. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: "/",
                            className: "andro_btn-custom light",
                            children: "Shop Now"
                        })
                    ]
                })
            })
        });
    }
}
/* harmony default export */ const home_Cta = (Cta);

;// CONCATENATED MODULE: ./components/Sections/home/AgricultureOthers.js




class AgricultureOthers extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            modalshow: false
        };
        this.modalShow = this.modalShow.bind(this);
        this.modalClose = this.modalClose.bind(this);
    }
    // Modal
    modalShow() {
        this.setState({
            modalshow: true
        });
    }
    modalClose() {
        this.setState({
            modalshow: false
        });
    }
    render() {
        const { BooksInfoList  } = this.props;
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section-title",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "title",
                        children: this.props.t("Products.BooksAndInfo")
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: BooksInfoList.slice(0, 3).map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4 col-xs-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "andro_product andro_product-minimal andro_product-has-controls andro_product-has-buttons",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "andro_product-thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: item.img,
                                            alt: item.title,
                                            className: "img-rounded"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "andro_product-body",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "andro_product-title",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                href: "/product-single/" + item.id,
                                                children: " Names Goes here "
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "andro_product-footer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "andro_product-buttons",
                                            style: {
                                                display: "block"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                href: "/product-single/" + item.id,
                                                className: "agri-btn-rounded primary",
                                                children: this.props.t("Products.ReadMore")
                                            })
                                        })
                                    })
                                ]
                            })
                        }, i))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                    href: "#",
                    className: "agri-btn-rounded-dark",
                    children: this.props.t("Products.ViewAll")
                })
            ]
        });
    }
}
/* harmony default export */ const home_AgricultureOthers = ((0,external_react_multi_lang_.withTranslation)(AgricultureOthers));

;// CONCATENATED MODULE: ./components/Sections/home/HomeContent.js






class HomeContent extends external_react_.Component {
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(home_HomeBanner, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(BestProducts_BestProducts, {
                    ProductList: this.props.ProductList
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section pt-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(home_Cta, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "section pt-0 andro_fresh-arrivals",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-8 col-md-8 col-xs-12",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(home_AgricultureOthers, {
                                        BooksInfoList: this.props.BooksInfoList
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-4 col-md-4 col-xs-12",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        style: {
                                            width: "100%"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "img/videoFull.png",
                                            alt: "agriculture_video",
                                            className: "img-fluid h-100"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const home_HomeContent = (HomeContent);

// EXTERNAL MODULE: ./data/products.json
var products = __webpack_require__(7216);
;// CONCATENATED MODULE: ./pages/index.js



function Home(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx(home_HomeContent, {
        ProductList: products,
        BooksInfoList: props.BooksInfoList
    });
}
const getStaticProps = async ()=>{
    return {
        props: {
            ProductList: products,
            BooksInfoList: products
        }
    };
};


/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("next/Link");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4243:
/***/ ((module) => {

module.exports = require("react-multi-lang");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5635:
/***/ ((module) => {

module.exports = JSON.parse('[{"icon":"flaticon-diet","title":"Food","slug":"Agri-food"},{"icon":"flaticon-supplements","title":"Supplements","slug":"Agri-food"},{"icon":"flaticon-groceries","title":"Baskets","slug":"Agri-basket"},{"icon":"flaticon-cleaning-spray","title":"Home Care","slug":"Agri-Cleaning"},{"icon":"flaticon-baby","title":"Kids Care","slug":"Agri-Kids"},{"icon":"flaticon-olive-oil","title":"Oils","slug":"Agri-Oils"}]');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [216], () => (__webpack_exec__(5050)));
module.exports = __webpack_exports__;

})();