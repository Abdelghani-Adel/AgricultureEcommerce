"use strict";
(() => {
var exports = {};
exports.id = 136;
exports.ids = [136];
exports.modules = {

/***/ 8176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ Rating)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__);


function Rating(rating) {
    let stars = [];
    for(let i = 0; i < 5; i++){
        stars.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaStar, {}, i));
    }
    if (rating && rating > 0) {
        for(let i1 = 0; i1 <= rating - 1; i1++){
            stars[i1] = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaStar, {
                className: "active"
            }, i1);
        }
    }
    return stars;
}



/***/ }),

/***/ 9291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _categorySlug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-multi-lang"
var external_react_multi_lang_ = __webpack_require__(4243);
// EXTERNAL MODULE: ./components/layout/Reusable/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(6946);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: external "react-paginate"
const external_react_paginate_namespaceObject = require("react-paginate");
var external_react_paginate_default = /*#__PURE__*/__webpack_require__.n(external_react_paginate_namespaceObject);
;// CONCATENATED MODULE: ./components/layout/Reusable/Loader.js


class Loader extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "pagination-loader",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                style: {
                    margin: "auto",
                    background: "#fff",
                    display: "block",
                    shapeRendering: "auto"
                },
                width: "200px",
                height: "200px",
                viewBox: "0 0 100 100",
                preserveAspectRatio: "xMidYMid",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(80,50)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(0)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.875s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.875s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(71.21320343559643,71.21320343559643)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(45)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.875",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.75s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.75s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(50,80)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(90)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.75",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.625s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.625s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(28.786796564403577,71.21320343559643)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(135)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.625",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.5s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.5s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(20,50.00000000000001)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(180)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.375s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.375s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(28.78679656440357,28.786796564403577)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(225)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.375",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.25s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.25s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(49.99999999999999,20)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(270)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.25",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "-0.125s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "-0.125s"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                        transform: "translate(71.21320343559643,28.78679656440357)",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                            transform: "rotate(315)",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                                cx: 0,
                                cy: 0,
                                r: 6,
                                fill: "#50BD4D",
                                fillOpacity: "0.125",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                                        attributeName: "transform",
                                        type: "scale",
                                        begin: "0s",
                                        values: "1.5 1.5;1 1",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                                        attributeName: "fill-opacity",
                                        keyTimes: "0;1",
                                        dur: "1s",
                                        repeatCount: "indefinite",
                                        values: "1;0",
                                        begin: "0s"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const Reusable_Loader = (Loader);

// EXTERNAL MODULE: external "next/Link"
var Link_ = __webpack_require__(514);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: ./helper/helper.js
var helper = __webpack_require__(8176);
;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCard/ProductDetails.js




const ProductDetails = (props)=>{
    const { product  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "andro_product-body",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                className: "andro_product-title",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                    href: props.productPath,
                    children: [
                        " ",
                        product.Item_Code,
                        " "
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "andro_product-price",
                children: product.discount > 0 || product.discount !== "" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        product.price,
                        " 49 $"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                dangerouslySetInnerHTML: {
                    __html: product.Item_HTML
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_rating-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "andro_rating",
                        children: (0,helper/* Rating */.i)(product.rating)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        children: [
                            product.rating,
                            props.t("Products.Stars")
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ProductCard_ProductDetails = ((0,external_react_multi_lang_.withTranslation)(ProductDetails));

// EXTERNAL MODULE: ./components/Sections/products/AddToCart.js
var AddToCart = __webpack_require__(2106);
;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCard/ProductFooter.js





const ProductFooter = (props)=>{
    const { product  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_product-footer",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "andro_product-controls",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(AddToCart/* default */.Z, {
                    item: product
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                    href: props.productPath,
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: props.t("Products.ViewDetails"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegEye, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                    href: "#",
                    className: "favorite",
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: props.t("Products.AddToWish"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegHeart, {})
                })
            ]
        })
    });
};
/* harmony default export */ const ProductCard_ProductFooter = ((0,external_react_multi_lang_.withTranslation)(ProductFooter));

;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCard/ProductStickers.js



const ProductStickers = (props)=>{
    const { product  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            product.featured === true && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_product-badge andro_badge-featured",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaStar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Featured"
                    })
                ]
            }),
            (product.discount > 0 || product.discount !== "") && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_product-badge andro_badge-sale",
                children: [
                    product.discount,
                    "% Off "
                ]
            })
        ]
    });
};
/* harmony default export */ const ProductCard_ProductStickers = (ProductStickers);

;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCard/ProductThumb.js


const ProductThumb = (props)=>{
    const { product  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_product-thumb text-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
            href: props.productPath,
            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                src: product.Item_Image,
                alt: product.title
            })
        })
    });
};
/* harmony default export */ const ProductCard_ProductThumb = (ProductThumb);

;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCard/ProductCard.js






const ProductCard = (props)=>{
    const { product  } = props;
    const productPath = `/products/${product.Item_Slug || "slugNotFound"}?id=${product.Item_Id}`;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-md-4 col-sm-6 col-xs-12 masonry-item",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "andro_product andro_product-has-controls",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductStickers, {
                    product: product,
                    productPath: productPath
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductThumb, {
                    product: product,
                    productPath: productPath
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductDetails, {
                    product: product,
                    productPath: productPath
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductFooter, {
                    product: product,
                    productPath: productPath
                })
            ]
        })
    });
};
/* harmony default export */ const ProductCard_ProductCard = ((0,external_react_multi_lang_.withTranslation)(ProductCard));

;// CONCATENATED MODULE: ./components/Sections/products/ProductCardList/ProductCardList.js



const ProductCardList = (props)=>{
    const { products  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: products.length > 0 ? products.map((product, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductCard, {
                product: product
            }, index)) : /*#__PURE__*/ jsx_runtime_.jsx("h1", {
            className: "text-center m-4",
            children: "No Products Found !"
        })
    });
};
/* harmony default export */ const ProductCardList_ProductCardList = (ProductCardList);

;// CONCATENATED MODULE: ./components/Sections/categories/CategoryProducts/FilterPrice.js

const FilterPrice = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar-widget",
        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
            className: "widget-title",
            children: " Price "
        })
    });
};
/* harmony default export */ const CategoryProducts_FilterPrice = (FilterPrice);

;// CONCATENATED MODULE: ./components/Sections/categories/CategoryProducts/FilterState.js

const FilterState = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar-widget",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                className: "widget-title",
                children: " Brand "
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "sidebar-widget-list"
            })
        ]
    });
};
/* harmony default export */ const CategoryProducts_FilterState = (FilterState);

;// CONCATENATED MODULE: ./components/Sections/categories/CategoryProducts/ProductCount.js



const ProductCount = (props)=>{
    // const { Items, total } = props;
    const [itemsPerPage, setItemsPerPage] = (0,external_react_.useState)(0);
    const [Items, setItems] = (0,external_react_.useState)([]);
    const [total, settotal] = (0,external_react_.useState)(0);
    // if (total < itemsPerPage) {
    //   itemsPerPage = total;
    // }
    (0,external_react_.useEffect)(()=>{
        setItemsPerPage(props.itemsPerPage);
        settotal(props.total);
        setItems(props.Items);
    }, []);
    (0,external_react_.useEffect)(()=>{
        setItemsPerPage(props.itemsPerPage);
        settotal(props.total);
        setItems(props.Items);
    }, [
        props
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "andro_shop-global",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
            children: [
                "Showing ",
                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                    children: itemsPerPage
                }),
                " of ",
                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                    children: total > 0 ? total : itemsPerPage
                }),
                " products"
            ]
        })
    });
};
/* harmony default export */ const CategoryProducts_ProductCount = ((0,external_react_multi_lang_.withTranslation)(ProductCount));

;// CONCATENATED MODULE: ./components/Sections/categories/CategoryProducts/SearchCategory.js

const SearchCategory = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar-widget widget-search",
        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
            method: "post",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "andro_search-adv-input",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        className: "form-control",
                        placeholder: "Look for Fruits, Vegetables",
                        name: "search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "submit",
                        name: "button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-search"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const CategoryProducts_SearchCategory = (SearchCategory);

;// CONCATENATED MODULE: ./components/Sections/categories/CategoryProducts/CategoryProducts.js













const CategoryProducts = (props)=>{
    const [products, setProducts] = (0,external_react_.useState)(props.products.data);
    const [productsTotal, setproductsTotal] = (0,external_react_.useState)(props.products.total);
    console.log("rerendered");
    console.log(props.products);
    // const productsTotal = props.products.total;
    const router = (0,router_.useRouter)();
    const [currentPage, setCurrentPage] = (0,external_react_.useState)(1);
    const [itemsPerPage, setItemsPerPage] = (0,external_react_.useState)(6);
    const [loading, setLoading] = (0,external_react_.useState)(false);
    const [itemOffset, setItemOffset] = (0,external_react_.useState)(0);
    const [pageCount, setPageCount] = (0,external_react_.useState)(Math.ceil(products != null ? products.length : 0 / itemsPerPage));
    const [endOffset, setEndOffset] = (0,external_react_.useState)(itemOffset + itemsPerPage);
    const [currentItems, setCurrentItems] = (0,external_react_.useState)(products != null ? products.slice(itemOffset, endOffset) : []);
    const [currentStart, setCurrentStart] = (0,external_react_.useState)(0);
    const changePageHandler = (event)=>{
        // const basePath = router.asPath.substring(0, router.asPath.indexOf("?"));
        const basePath = router.asPath;
        // router.push(`${basePath}&start=${itemOffset}`);
        console.log(itemOffset);
        console.log(endOffset);
        console.log(basePath);
        const newOffset = event.selected * itemsPerPage % products.length;
        const newEndOffset = newOffset + itemsPerPage;
        setLoading(true);
        setCurrentStart();
        setItemOffset(event.selected * itemsPerPage % products.length);
        setCurrentItems(products.slice(newOffset, newEndOffset));
        setLoading(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "section pagination-content",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "andro_section-fw",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-9 col-xs-12",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(CategoryProducts_ProductCount, {
                                Items: products,
                                itemsPerPage: currentItems.length,
                                total: productsTotal
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row",
                                children: loading === false ? /*#__PURE__*/ jsx_runtime_.jsx(ProductCardList_ProductCardList, {
                                    products: currentItems,
                                    slug: props.slug
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(Reusable_Loader, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-xs-12",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "sidebar",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(CategoryProducts_SearchCategory, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(CategoryProducts_FilterState, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(CategoryProducts_FilterPrice, {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-9 col-xs-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_paginate_default()), {
                            breakLabel: "...",
                            nextLabel: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleRight, {}),
                            onPageChange: changePageHandler,
                            pageRangeDisplayed: 5,
                            pageCount: pageCount,
                            previousLabel: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleLeft, {}),
                            renderOnZeroPageCount: null,
                            className: "pagination"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const CategoryProducts_CategoryProducts = ((0,external_react_multi_lang_.withTranslation)(CategoryProducts));

;// CONCATENATED MODULE: ./components/Sections/categories/SubCategories/SubCategories.js



const SubCategories = (props)=>{
    const { categories  } = props;
    console.log(categories);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "section",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: categories.map((subCategory, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-xs-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: `/categories/${subCategory.FAClassificationSlug}?id=${subCategory.FAClassificationId}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "card catg_card",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: "card-img-top",
                                        src: subCategory.FAClassificationImage,
                                        alt: "Card image cap"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "card-body",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                className: "card-title",
                                                children: subCategory.FAClassificationName
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "card-text",
                                                dangerouslySetInnerHTML: {
                                                    __html: subCategory.FAClassificationDesc
                                                }
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }, index))
            })
        })
    });
};
/* harmony default export */ const SubCategories_SubCategories = ((0,external_react_multi_lang_.withTranslation)(SubCategories));

;// CONCATENATED MODULE: ./pages/categories/[categorySlug]/index.js






const CategorySingle = (props)=>{
    const { categories , showProducts , products  } = props;
    const router = (0,router_.useRouter)();
    // console.log(props.products);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                breadcrumb: {
                    pagename: router.query.categorySlug
                }
            }),
            showProducts ? /*#__PURE__*/ jsx_runtime_.jsx(CategoryProducts_CategoryProducts, {
                products: props.products,
                slug: router.query.categorySlug
            }) : /*#__PURE__*/ jsx_runtime_.jsx(SubCategories_SubCategories, {
                categories: categories
            })
        ]
    });
};
const getServerSideProps = async (ctx)=>{
    // API fetch to get the array of sub_categories
    const subCategoriesRes = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/ECommerceSetting/GetCategoriesMenu`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            lang: "ar",
            FAClassification_ParentId: ctx.query.id
        })
    });
    const subCategories = await subCategoriesRes.json();
    if (subCategories.length > 0) {
        return {
            props: {
                categories: subCategories,
                categorySlug: ctx.params.categorySlug,
                showProducts: false
            }
        };
    }
    // API fetch to get the array of products | send slug || get the products
    const productsRes = await fetch(`${"https://adminecommerce.devsdiamond.com"}/api/ECommerceSetting/getItemMainByCategory`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            lang: "ar",
            Cate_Id: ctx.query.id,
            limit: 6,
            start: 1
        })
    });
    const products = await productsRes.json();
    return {
        props: {
            products: products,
            categorySlug: ctx.params.categorySlug,
            id: ctx.query.id,
            test: products,
            showProducts: true
        }
    };
};
/* harmony default export */ const _categorySlug_ = ((0,external_react_multi_lang_.withTranslation)(CategorySingle));


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("next/Link");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4243:
/***/ ((module) => {

module.exports = require("react-multi-lang");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [946,586,106], () => (__webpack_exec__(9291)));
module.exports = __webpack_exports__;

})();